##### 2do Proyecto 

listadecon = [["7"]]

usuario = input("Teclea el número 7 y despúes da Enter para continuar ")


acc = 0
n_veces = 1
 
for u in listadecon :
  if usuario == u[0] :
    acc = acc + 1

while acc == 1 and n_veces  < 2 :
  
  print("Opciones para Synergy Logistics ","\n\n" )

  ###Importación de Datos para trabajar 

  import csv

  ##Declaro la lista vacia Datos para poder llenarla con la información del csv

  Datos = []

  # Con la función with y acompañado de un open descardo en modo lector (Es poe eso la coma y el r entre comillas, para guardarla en la variable Data, para despuespues leerla y designarla a la variable lector, la cual itero en un for, para llenar mi lsita vacía Datos y de esta manera tener acomodado los datos de mi csv ya dentro de una lista en mi programa.)

  with open("synergy_logistics_database.csv", "r") as Data:
    lector = csv.reader(Data)

    for linea in lector:
      Datos.append(linea)

  #Aquí elimino el primer renglon ya que me estorba para filtras unos datos, con las función pop    
  Datos.pop(0)


  print("\n")


  print("Opción 1) Rutas de importación y exportación. ")
  ### Punto 1 Generación de Rutas ##
  #### Generar RUTAS DE EXPORTACIÓN 


  ####Gerenación de Rutas de Exportaciones

  # En esta parte del codigo declaro 1 variable de contador con la cúal contaré las veces que se utilizo una ruta, 2 listas las cuales en rutascontadas voy actualizando la lista con rutas que no son repetidas, para que a su vez si ocurre eso el contador vaya aumentando.

  # En el for inicializado en la linea debajo de las variables vacias iré llenando la variable rutaactual con cada una de las rutas que va recorrieendo el for en la posición 2 y 3, la cual si no esta añadida en la lista rutascontadas, la añade en el for de la linea 42, en la cual actualiza la lista de rutascontadas, y actualiza el contador de cuantas veces ya a sido reocrrida esa ruta, por lo que en la linea 47 se agrega a la lista finla de conteorutas, la lista con todas las rutas que hay en la empresa, ademas indicando cuantas veces han sido recorridas, por último en la linea 49, limpiamos el contador para que no de valores erroneos de contar 2 o más veces la misma ruta de diferente dirección.        Es imprtante mencionar que en la linea 43 en la condición del if se vuelve a filtrar que solo se agreguen las rutas que aparece en las los renglones que diga de la colmna 1 Exports, ya que si no lo hiciera así se agregarían tambien las que dicen "Imports", por lo cual aseguro que mi conteo indica realmente que cumpla la condición de que se filtan las exportaciones y me indica cuantas veces se han recorrido, despues se ordena la lista con las rutas  de mayor a menor con la función sort de la lines 52, y en la línea 54 solo se extraen las primeras 10 ya que son las solicitadas, por último en el for de la linea 62 se imprime en la 63 para mejor estetica.

  con =  0
  rutascontadas = []
  conteorutas = [] 


  for ruta in Datos:
    if ruta[1] == "Exports":
      rutaactual = [ruta[2], ruta[3]]

      if rutaactual not in rutascontadas:
        for movimiento in Datos:
          if rutaactual == [movimiento[2],movimiento[3]] and movimiento [1] == "Exports":
            con += 1

        rutascontadas.append(rutaactual)
        conteorutas.append([con, "Veces se utilizó la ruta", ruta[2], '-' , ruta[3]])
        
        con = 0
        

  conteorutas.sort(reverse = True)

  h = conteorutas[0:10]

  print("\n")

  print("Las 10 rutas más demandadas para las exportaciones fueron:")

  print("\n")

  for k in h:
    print(k)




  print("\n\n")

  #### Generar RUTAS DE IMPORTACIONES 

  ### Realmente es el mismo procedmiento que en el de exportaciónes pero ahora con las importaciones, se que se podía hacer con una función y se vería más estetico, pero realmente yo me acomode más de esta manera.

  con =  0
  rutascontadas = []
  conteorutas = []


  for ruta in Datos:
    if ruta[1] == "Imports":
      rutaactual = [ruta[2], ruta[3]]

      if rutaactual not in rutascontadas:
        for movimiento in Datos:
          if rutaactual == [movimiento[2],movimiento[3]] and movimiento[1] == "Imports":
            con += 1

        rutascontadas.append(rutaactual)
        conteorutas.append([con,"Veces se utilizó la ruta",ruta[2], ruta[3]])
        con = 0

  conteorutas.sort(reverse = True)

  h = conteorutas[0:10]

  print("Las 10 rutas más demandadas para las importaciones fueron:")

  print("\n")

  for k in h:
    print(k)

  print("\n\n")

  print("\n")
  print("\n")
  print("\n")

  print("Opción 2) Medio de transporte utilizado. ")

  print("\n")
  ###### Punto 2 Medios de Transporte 




  ### Por Mar 

  ## Lo que hice en este punto fue crear una lista vacía llamada "gana", donde en el for que esta debajo de las variables vacias iba llenando de manera que si en la columna 7 aparecia "Sea" argregara el valor de de esa importación ó exportación maritima, para que en la linea debajo de donde iba agregando con la función append el contador inicializado en 0 llamdo su fuera sumnado para ver cuantas veces se utilizo ese medio de transporte y por ultimo implimiendolo fuera del for cada variable con sus valores actuales.

  gana = []
  su = 0
  for i in Datos:
    if i[7] == "Sea":
      gana.append(int(i[9]))
      su = su + 1
  r = sum(gana)

  print(su,"Viajes por Mar se han hecho, lo cual han generado ",r ,'$',"\n")


  #Ahora con la misma idea que arriba en solo saber si era medio de transporte marítimo, ahora lo hago agregando la condición and de que también pido si son Importaciones para hacer esa diferenciación en la liena debajo del for en la condición del if agrego esa condicón and que explique en este parrafo.

  gana = []
  su = 0
  for i in Datos:
    if i[7] == "Sea" and i[1] == "Imports":
      gana.append(int(i[9]))
      su = su + 1
  r = sum(gana)
  print(su,"Importaciones por Mar se han hecho, lo cual han generado ",r ,'$',"\n")

  # La misma idea que arriba en las importaciones, pero ahora con las exportaciones 

  gana = []
  su = 0
  for i in Datos:
    if i[7] == "Sea" and i[1] == "Exports":
      gana.append(int(i[9]))
      su = su + 1
  r = sum(gana)

  print(su,"Exportaciones por Mar se han hecho, lo cual han generado ",r ,'$',"\n")

  print("\n")

  ### Por Tren

  #### Hice lo mismo que hice para el mar para el medio de transporte del Tren 

  gana = []
  su = 0
  for i in Datos:
    if i[7] == "Rail":
      gana.append(int(i[9]))
      su = su + 1
  r = sum(gana)

  print(su,"Viajes por Tren se han hecho, lo cual han generado ",r ,'$',"\n")


  gana = []
  su = 0
  for i in Datos:
    if i[7] == "Rail" and i[1] == "Imports":
      gana.append(int(i[9]))
      su = su + 1
  r = sum(gana)

  print(su,"Importaciones por Tren se han hecho, lo cual han generado ",r ,'$',"\n")


  gana = []
  su = 0
  for i in Datos:
    if i[7] == "Rail" and i[1] == "Exports":
      gana.append(int(i[9]))
      su = su + 1
  r = sum(gana)
  print(su,"Exportaciones por Tren se han hecho, lo cual han generado ",r ,'$',"\n")

  print("\n")
  ### Por Aire 

  #### Hice lo mismo que hice para el mar para el medio de transporte del Aire

  gana = []
  su = 0
  for i in Datos:
    if i[7] == "Air":
      gana.append(int(i[9]))
      su = su + 1
  r = sum(gana)

  print(su,"Viajes por Aire se han hecho, lo cual han generado ",r ,'$',"\n")




  gana = []
  su = 0
  for i in Datos:
    if i[7] == "Air"and i[1] == "Imports":
      gana.append(int(i[9]))
      su = su + 1
  r = sum(gana)

  print(su,"Importaciones por Aire se han hecho, lo cual han generado ",r ,'$',"\n")



  gana = []
  su = 0
  for i in Datos:
    if i[7] == "Air"and i[1] == "Exports":
      gana.append(int(i[9]))
      su = su + 1
  r = sum(gana)
  print(su,"Exportaciones por Aire se han hecho, lo cual han generado ",r ,'$',"\n")

  print("\n")
  ##### Por camión 

  #### Hice lo mismo que hice para el mar para el medio de transporte del Camión ó Terrestre

  gana = []
  su = 0
  for i in Datos:
    if i[7] == "Road":
      gana.append(int(i[9]))
      su = su + 1
  r = sum(gana)

  print(su,"Viajes por Carretera se han hecho, lo cual han generado ",r ,'$',"\n")


  gana = []
  su = 0
  for i in Datos:
    if i[7] == "Road" and i[1] == "Imports":
      gana.append(int(i[9]))
      su = su + 1
  r = sum(gana)
  print(su,"Importaciones por Carretera se han hecho, lo cual han generado ",r ,'$',"\n")

  gana = []
  su = 0
  for i in Datos:
    if i[7] == "Road" and i[1] == "Exports":
      gana.append(int(i[9]))
      su = su + 1
  r = sum(gana)
  print(su,"Exportaciones por Carretera se han hecho, lo cual han generado ",r ,'$',"\n")

  print("\n")
  print("\n")
  print("\n")

  print("Opción 3) Valor total de importaciones y exportaciones.")

  print("\n")

  # 3) Valor total de importaciones y exportaciones.

  # Para el punto 3 decidí sacar unos valores que me serían útiles para mi mejor analisis de los datos y sacarlos de forma correcta, así que meidante un for saque el total de todo, primero fueron el total de transacciones de Exportaciónes o Importaciones hechas y el cuanto habían generado, esto con metodos ya vistos antes ya adaptados a esta problematica, en la cual en la lista Cos la llene con todos los flujos de efectivo resultantes de todas las operaciones, y en la variable ff pedí su longitud para saber cuantos eran y adepatarlos a un print y en la variable gg tengo la suma total de efectivo total de la empresa.


  Paises = []
  su = 0
  Cos = []

  for i in Datos:
    if i[9] == i[9] :
      Cos.append(int(i[9]))
      su = su + 1

  ff = len(Cos)
  gg= sum(Cos)

  print("El total de Exportaciones e Importaciones de la empresa son: ", ff,"Las cuales generaroan",gg,"$" )
  print("\n")

  # Caso similar al global enuncuado en el parrafo de arriba lo hice para las Importaciones y Exportaciones, solo que agregando la condición and en el if para filtrar solamente los flujos de efectivo ya sea de importación o de expotación.

  Paises = []
  su = 0
  Cos = []

  for i in Datos:
    if i[9] == i[9] and i[1] == "Imports":
      Cos.append(int(i[9]))
      su = su + 1

  ff = len(Cos)
  gg= sum(Cos)

  print("El total de Importaciones de la empresa son: ", ff,"Las cuales generaroan",gg,"$" )

  print("\n")




  Paises = []
  su = 0
  Cos = []

  for i in Datos:
    if i[9] == i[9] and i[1] == "Exports":
      Cos.append(int(i[9]))
      su = su + 1
  ff = len(Cos)
  gg= sum(Cos)

  print("El total de Exportaciones de la empresa son: ", ff,"Las cuales generaroan",gg,"$" )

  print("\n")


  ### Al tener los totales de exportaciones  y de importaciones los copie a la variable T, en la cual incluye el total de exportaciones en este caso, esto para sacar la proporción por país que logran sumar el 80% de los paises más exportadores ó más importadores, por lo cual declaro dos comtadores que me serviran para 2 cosas; con me sivre para contar cuantas importaciones/exportaciones hizo el país x, y con2 me sirve para tener la suma de cuanto due lo que genero ese país en terminos economicos ya sea en manera de exportación/importación. En las listas de rutascontadas y conteorutas se utiliza el mismo procedmiento que en el punto 1 y ahí viene bien explicado lo que se hacen con esas listas y y como se llenan con los for correcponeidnte, solo que en este caso la vairante más importante es como determinar el porcentaje de cada país, por lo cual lo que hago en la linea 335 es haces que se actualice el valor de con2 con la suma del valor de alguna exportación de algun país especifico y se le vuelva a sumar lo que ya tiene guardado de suma anterior ese país y todo eso dividirlo entre T, que es el total de exportaciones/importaciones y multiplicandolo por 100 para sacar su porcentaje final en la linea 338, para irlo agregando en la lista conteorutas.

  con =  0
  con2 = 0
  rutascontadas = []
  conteorutas = []
  T = 160163298000

  for ruta in Datos:
    if ruta[2] == ruta[2] and ruta[1] == "Exports":
      rutaactual = ruta[2]

      if rutaactual not in rutascontadas and ruta[1] == "Exports":
        for movimiento in Datos:
          if rutaactual == movimiento[2] and movimiento[1] == "Exports":
            con += 1
            con2 = int(movimiento[9]) + con2
            
        rutascontadas.append(rutaactual)
        conteorutas.append([((con2)/T)*100 ,'%', ruta[2],'con', con,'Exportaciones hechas'])
        con = 0
        con2 = 0

  conteorutas.sort(reverse = True)

  h = conteorutas[0:8]

  print("\n")

  print("Los países que generan el 80% del valor de las exportaciones son: ")

  print("\n")

  for k in h:
    print(k)




  print("\n\n")

  con =  0
  con2 = 0
  rutascontadas = []
  conteorutas = []
  T = 55528000000

  for ruta in Datos:
    if ruta[3] == ruta[3] and ruta[1] == "Imports":
      rutaactual = ruta[3]

      if rutaactual not in rutascontadas and ruta[1] == "Imports":
        for movimiento in Datos:
          if rutaactual == movimiento[3] and movimiento[1] == "Imports":
            con += 1
            con2 = int(movimiento[9]) + con2
            
        rutascontadas.append(rutaactual)
        conteorutas.append([((con2)/T)*100 ,'%', ruta[3],'con', con,'Importaciones hechas'])
        con = 0
        con2 = 0

  conteorutas.sort(reverse = True)

  h = conteorutas[0:6]

  print("\n")

  print("Los países que generan el 80% del valor de las importaciones son: ")

  print("\n")

  for k in h:
    print(k)

  n_veces += 1


print("Gracias")